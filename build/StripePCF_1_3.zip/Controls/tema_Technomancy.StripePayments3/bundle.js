/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./StripePayments/index.ts":
/*!*********************************!*\
  !*** ./StripePayments/index.ts ***!
  \*********************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

eval("\n\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.StripePayments3 = void 0;\nvar stripe_js_1 = __webpack_require__(/*! @stripe/stripe-js */ \"./node_modules/@stripe/stripe-js/dist/stripe.esm.js\");\nvar STATUS_NEW = \"new\";\nvar STATUS_ERROR = \"error\";\nvar STATUS_PROCESSING = \"processing\";\nvar STATUS_COMPLETED = \"completed\";\nvar StripePayments3 = /** @class */function () {\n  /**\r\n   * Empty constructor.\r\n   */\n  function StripePayments3() {}\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here, use updateView.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   * @param container If a control is marked control-type='standard', it will receive an empty div element within which it can render its content.\r\n   */\n  StripePayments3.prototype.init = function (context, notifyOutputChanged, state, container) {\n    var _this = this;\n    this.has_been_reset = false;\n    this.payment_status = STATUS_NEW;\n    this._notifyOutputChanged = notifyOutputChanged;\n    container.appendChild(this.getHTMLElements());\n    document.getElementById(\"payment-form\").addEventListener(\"submit\", function (event) {\n      event.preventDefault();\n      _this.pay();\n    });\n  };\n  StripePayments3.prototype.initStripeClient = function () {\n    var _this = this;\n    var stripePromise = (0, stripe_js_1.loadStripe)(this.stripe_client_key);\n    stripePromise.then(function (stripe) {\n      if (stripe) {\n        _this._stripe = stripe;\n        _this._elements = stripe.elements();\n        _this.createCardElement();\n        document.querySelector(\"#sr-not-initialised\").classList.add(\"hidden\");\n        document.querySelector(\"#payment-form\").classList.remove(\"hidden\");\n      }\n    });\n  };\n  StripePayments3.prototype.createCardElement = function () {\n    if (this._elements) {\n      console.log(\"Recreating card element.\");\n      this._card = this._elements.create(\"card\", this.getCardElementOptions());\n      this._card.mount(\"#card-element\");\n      this._card.on('change', function (_a) {\n        var error = _a.error;\n        var displayError = document.getElementById('card-errors');\n        if (displayError) displayError.innerText = error ? error.message : \"\";\n      });\n    }\n  };\n  StripePayments3.prototype.getCardElementOptions = function () {\n    return {\n      style: {\n        base: {\n          color: \"#32325d\",\n          fontFamily: '\"Helvetica Neue\", Helvetica, sans-serif',\n          fontSize: this.card_font_size + 'pt',\n          fontSmoothing: \"antialiased\",\n          \"::placeholder\": {\n            color: \"#aab7c4\"\n          }\n        },\n        invalid: {\n          color: \"#fa755a\",\n          iconColor: \"#fa755a\"\n        }\n      },\n      hidePostalCode: !this.prop_ZIP_code\n    };\n  };\n  StripePayments3.prototype.cleanupStripeClient = function () {\n    document.querySelector(\"#sr-not-initialised\").classList.remove(\"hidden\");\n    document.querySelector(\"#payment-form\").classList.add(\"hidden\");\n    if (this._card) this._card.destroy;\n    this._card = undefined;\n    this._elements = undefined;\n    this._stripe = undefined;\n  };\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   */\n  StripePayments3.prototype.updateView = function (context) {\n    this.prop_customer = context.parameters.Customer.raw || \"\";\n    this.payment_intent_client_secret = context.parameters.PaymentIntentClientSecret.raw || \"\";\n    if (this.stripe_client_key != context.parameters.StripeClientKey.raw) {\n      this.stripe_client_key = context.parameters.StripeClientKey.raw || \"\";\n      this.cleanupStripeClient();\n      if (!this._stripe && this.stripe_client_key) this.initStripeClient();\n    }\n    if (this.card_font_size != context.parameters.CardFontSize.raw || this.prop_ZIP_code != context.parameters.ZipcodeElement.raw || this.error_font_size != context.parameters.ErrorFontSize.raw) {\n      this.prop_ZIP_code = context.parameters.ZipcodeElement.raw || false;\n      this.card_font_size = context.parameters.CardFontSize.raw || 20;\n      if (this._card) this._card.destroy();\n      this.createCardElement();\n    }\n    if (this.button_font_size != context.parameters.ButtonFontSize.raw) {\n      this.button_font_size = context.parameters.ButtonFontSize.raw || 20;\n      document.documentElement.style.setProperty(\"--button-font-size\", this.button_font_size + \"pt\");\n    }\n    if (this.error_font_size != context.parameters.ErrorFontSize.raw) {\n      this.error_font_size = context.parameters.ErrorFontSize.raw || 20;\n      document.documentElement.style.setProperty(\"--error-font-size\", this.error_font_size + \"pt\");\n    }\n    if (context.parameters.Reset.raw && !this.has_been_reset) {\n      this.setStatus(STATUS_NEW);\n      this.has_been_reset = true;\n      if (this._card) this._card.clear();\n      this.reset();\n    } else this.has_been_reset = false;\n  };\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”\r\n   */\n  StripePayments3.prototype.getOutputs = function () {\n    return {\n      PaymentStatus: this.payment_status\n    };\n  };\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n  StripePayments3.prototype.destroy = function () {\n    this.cleanupStripeClient();\n  };\n  StripePayments3.prototype.getHTMLElements = function () {\n    var html = \"   \\n\\t\\t\\t<div class=\\\"sr-main\\\">\\n\\t\\t\\t\\t<div id=\\\"sr-not-initialised\\\" class=\\\"sr-result\\\">\\n\\t\\t\\t\\t\\t<p>The component has not been initialised: set the StripeClientKey property</p>\\n\\t\\t\\t\\t</div>\\n\\t\\t\\t\\t<form id=\\\"payment-form\\\" class=\\\"sr-payment-form hidden\\\">\\n\\t\\t\\t\\t\\t<div class=\\\"sr-combo-inputs-row\\\">\\n\\t\\t\\t\\t\\t\\t<div class=\\\"sr-input sr-card-element\\\" id=\\\"card-element\\\"></div>\\n\\t\\t\\t\\t\\t</div>\\n\\t\\t\\t\\t\\t<div class=\\\"sr-field-error\\\" id=\\\"card-errors\\\" role=\\\"alert\\\"></div>\\n\\t\\t\\t\\t\\t<button id=\\\"submit\\\">\\n\\t\\t\\t\\t\\t\\t<div class=\\\"spinner hidden\\\" id=\\\"spinner\\\"></div>\\n\\t\\t\\t\\t\\t\\t<span id=\\\"button-text\\\">Pay</span>\\n\\t\\t\\t\\t\\t\\t<span id=\\\"order-amount\\\"></span>\\n\\t\\t\\t\\t\\t</button>\\n\\t\\t\\t\\t</form>\\n\\t\\t\\t\\t<div class=\\\"sr-result hidden\\\">\\n\\t\\t\\t\\t\\t<p>Payment completed<br /></p>\\n\\t\\t\\t\\t</div>\\n\\t\\t\\t</div>\";\n    var template = document.createElement('template');\n    html = html.trim(); // Never return a text node of whitespace as the result\n    template.innerHTML = html;\n    return template.content;\n  };\n  /*\r\n  * Calls stripe.confirmCardPayment which creates a pop-up modal to\r\n  * prompt the user to enter extra authentication details without leaving your page\r\n  */\n  StripePayments3.prototype.pay = function () {\n    var _this = this;\n    this.changeLoadingState(true);\n    this.setStatus(STATUS_PROCESSING);\n    try {\n      if (!this._stripe) if (this.stripe_client_key) this.initStripeClient();else throw \"ERROR: No PaymentIntentClientSecret specified\";\n      if (this._stripe && this._card && this.payment_intent_client_secret) {\n        this._stripe.confirmCardPayment(this.payment_intent_client_secret, this.prop_customer ? {\n          payment_method: {\n            card: this._card,\n            billing_details: {\n              name: this.prop_customer\n            }\n          }\n        } : {\n          payment_method: {\n            card: this._card\n          }\n        }).then(function (result) {\n          if (result.error) {\n            // Show error to your customer\n            _this.setStatus(STATUS_ERROR);\n            _this.showError(result.error.message);\n          } else {\n            // The payment has been processed!\n            _this.orderComplete();\n            _this.setStatus(STATUS_COMPLETED);\n          }\n        });\n      } else throw \"ERROR: Not initialised Stripe client or empty PaymentIntentClientSecret\";\n    } catch (err) {\n      this.setStatus(STATUS_ERROR);\n      console.log(err.message);\n      this.showError(\"The payment component has not been initialised properly. Did you set correct StripeClientKey and valid PaymentIntentClientSecret?\");\n    }\n  };\n  StripePayments3.prototype.setStatus = function (status) {\n    this.payment_status = status;\n    this._notifyOutputChanged();\n  };\n  /* ------- Post-payment helpers ------- */\n  StripePayments3.prototype.showError = function (errorMsgText) {\n    this.changeLoadingState(false);\n    var errorMsg = document.querySelector(\".sr-field-error\");\n    errorMsg.textContent = errorMsgText;\n    setTimeout(function () {\n      errorMsg.textContent = \"\";\n    }, 4000);\n  };\n  /* Shows a success / error message when the payment is complete */\n  StripePayments3.prototype.orderComplete = function () {\n    document.querySelector(\".sr-payment-form\").classList.add(\"hidden\");\n    document.querySelector(\".sr-result\").classList.remove(\"hidden\");\n    this.changeLoadingState(false);\n  };\n  // Resets the form status to new\n  StripePayments3.prototype.reset = function () {\n    document.querySelector(\".sr-payment-form\").classList.remove(\"hidden\");\n    document.querySelector(\".sr-result\").classList.add(\"hidden\");\n    this.changeLoadingState(false);\n  };\n  // Show a spinner on payment submission\n  StripePayments3.prototype.changeLoadingState = function (isLoading) {\n    if (isLoading) {\n      document.querySelector(\"button\").disabled = true;\n      document.querySelector(\"#spinner\").classList.remove(\"hidden\");\n      document.querySelector(\"#button-text\").classList.add(\"hidden\");\n    } else {\n      document.querySelector(\"button\").disabled = false;\n      document.querySelector(\"#spinner\").classList.add(\"hidden\");\n      document.querySelector(\"#button-text\").classList.remove(\"hidden\");\n    }\n  };\n  return StripePayments3;\n}();\nexports.StripePayments3 = StripePayments3;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./StripePayments/index.ts?");

/***/ }),

/***/ "./node_modules/@stripe/stripe-js/dist/stripe.esm.js":
/*!***********************************************************!*\
  !*** ./node_modules/@stripe/stripe-js/dist/stripe.esm.js ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   loadStripe: () => (/* binding */ loadStripe)\n/* harmony export */ });\nvar V3_URL = 'https://js.stripe.com/v3';\nvar V3_URL_REGEX = /^https:\\/\\/js\\.stripe\\.com\\/v3\\/?(\\?.*)?$/;\nvar EXISTING_SCRIPT_MESSAGE = 'loadStripe.setLoadParameters was called but an existing Stripe.js script already exists in the document; existing script parameters will be used';\nvar findScript = function findScript() {\n  var scripts = document.querySelectorAll(\"script[src^=\\\"\".concat(V3_URL, \"\\\"]\"));\n  for (var i = 0; i < scripts.length; i++) {\n    var script = scripts[i];\n    if (!V3_URL_REGEX.test(script.src)) {\n      continue;\n    }\n    return script;\n  }\n  return null;\n};\nvar injectScript = function injectScript(params) {\n  var queryString = params && !params.advancedFraudSignals ? '?advancedFraudSignals=false' : '';\n  var script = document.createElement('script');\n  script.src = \"\".concat(V3_URL).concat(queryString);\n  var headOrBody = document.head || document.body;\n  if (!headOrBody) {\n    throw new Error('Expected document.body not to be null. Stripe.js requires a <body> element.');\n  }\n  headOrBody.appendChild(script);\n  return script;\n};\nvar registerWrapper = function registerWrapper(stripe, startTime) {\n  if (!stripe || !stripe._registerWrapper) {\n    return;\n  }\n  stripe._registerWrapper({\n    name: 'stripe-js',\n    version: \"2.2.0\",\n    startTime: startTime\n  });\n};\nvar stripePromise = null;\nvar loadScript = function loadScript(params) {\n  // Ensure that we only attempt to load Stripe.js at most once\n  if (stripePromise !== null) {\n    return stripePromise;\n  }\n  stripePromise = new Promise(function (resolve, reject) {\n    if (typeof window === 'undefined' || typeof document === 'undefined') {\n      // Resolve to null when imported server side. This makes the module\n      // safe to import in an isomorphic code base.\n      resolve(null);\n      return;\n    }\n    if (window.Stripe && params) {\n      console.warn(EXISTING_SCRIPT_MESSAGE);\n    }\n    if (window.Stripe) {\n      resolve(window.Stripe);\n      return;\n    }\n    try {\n      var script = findScript();\n      if (script && params) {\n        console.warn(EXISTING_SCRIPT_MESSAGE);\n      } else if (!script) {\n        script = injectScript(params);\n      }\n      script.addEventListener('load', function () {\n        if (window.Stripe) {\n          resolve(window.Stripe);\n        } else {\n          reject(new Error('Stripe.js not available'));\n        }\n      });\n      script.addEventListener('error', function () {\n        reject(new Error('Failed to load Stripe.js'));\n      });\n    } catch (error) {\n      reject(error);\n      return;\n    }\n  });\n  return stripePromise;\n};\nvar initStripe = function initStripe(maybeStripe, args, startTime) {\n  if (maybeStripe === null) {\n    return null;\n  }\n  var stripe = maybeStripe.apply(undefined, args);\n  registerWrapper(stripe, startTime);\n  return stripe;\n}; // eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types\n\n// own script injection.\n\nvar stripePromise$1 = Promise.resolve().then(function () {\n  return loadScript(null);\n});\nvar loadCalled = false;\nstripePromise$1[\"catch\"](function (err) {\n  if (!loadCalled) {\n    console.warn(err);\n  }\n});\nvar loadStripe = function loadStripe() {\n  for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {\n    args[_key] = arguments[_key];\n  }\n  loadCalled = true;\n  var startTime = Date.now();\n  return stripePromise$1.then(function (maybeStripe) {\n    return initStripe(maybeStripe, args, startTime);\n  });\n};\n\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./node_modules/@stripe/stripe-js/dist/stripe.esm.js?");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = __webpack_require__("./StripePayments/index.ts");
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('Technomancy.StripePayments3', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.StripePayments3);
} else {
	var Technomancy = Technomancy || {};
	Technomancy.StripePayments3 = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.StripePayments3;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}